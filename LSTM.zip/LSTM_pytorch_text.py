# PYTORCH VERSION:
from tqdm import tqdm
import torch
import torch.nn as nn
import warnings
warnings.filterwarnings("ignore")

if torch.backends.mps.is_available():
	device = torch.device("mps")
elif torch.cuda.is_available():
	device = torch.device("cuda")
else:
	device = torch.device("cpu")

def sigmoid(x):
	return 1 / (1 + torch.exp(-x))


class LSTM(nn.Module):
	def __init__(self, input_size, hidden_size, embedding_size):
		super(LSTM, self).__init__()
		self.input_size = input_size
		self.hidden_size = hidden_size
		self.embedding_size = embedding_size

		self.embed_x_v = nn.Parameter(torch.Tensor(input_size, embedding_size))
		self.w_f_vh = nn.Parameter(torch.Tensor(embedding_size, hidden_size))
		self.w_f_sh = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
		self.b_f = nn.Parameter(torch.Tensor(hidden_size))
		self.w_i_LR_vh = nn.Parameter(torch.Tensor(embedding_size, hidden_size))
		self.w_i_LR_sh = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
		self.b_i_LR = nn.Parameter(torch.Tensor(hidden_size))
		self.w_i_UPD_vh = nn.Parameter(torch.Tensor(embedding_size, hidden_size))
		self.w_i_UPD_sh = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
		self.b_i_UPD = nn.Parameter(torch.Tensor(hidden_size))
		self.w_o_xh = nn.Parameter(torch.Tensor(embedding_size, hidden_size))
		self.w_o_sh = nn.Parameter(torch.Tensor(hidden_size, hidden_size))
		self.b_o = nn.Parameter(torch.Tensor(hidden_size))
		self.o_o = nn.Parameter(torch.Tensor(hidden_size, input_size))

		self.init_weights()

	def init_weights(self):
		nn.init.xavier_normal_(self.embed_x_v)
		nn.init.xavier_normal_(self.w_f_vh)
		nn.init.xavier_normal_(self.w_f_sh)
		nn.init.zeros_(self.b_f)
		nn.init.xavier_normal_(self.w_i_LR_vh)
		nn.init.xavier_normal_(self.w_i_LR_sh)
		nn.init.zeros_(self.b_i_LR)
		nn.init.xavier_normal_(self.w_i_UPD_vh)
		nn.init.xavier_normal_(self.w_i_UPD_sh)
		nn.init.zeros_(self.b_i_UPD)
		nn.init.xavier_normal_(self.w_o_xh)
		nn.init.xavier_normal_(self.w_o_sh)
		nn.init.zeros_(self.b_o)
		nn.init.xavier_normal_(self.o_o)

	def softmax(self, x):
		return torch.exp(x) / torch.sum(torch.exp(x), dim=0)
	
	def forward(self, x, short_term_mem, long_term_mem):
		# Embedding
		v = torch.tensordot(x, self.embed_x_v, dims=1)
		# Forget Gate
		f = sigmoid(torch.tensordot(v, self.w_f_vh, dims=1) + torch.tensordot(short_term_mem, self.w_f_sh, dims=1) + self.b_f)
		# modify long-term memory:
		long_term_mem = torch.mul(f, long_term_mem)
		# Input Gate
		i_LR = sigmoid(torch.tensordot(v, self.w_i_LR_vh, dims=1) + torch.tensordot(short_term_mem, self.w_i_LR_sh, dims=1) + self.b_i_LR)
		i_UPD = torch.tanh(torch.tensordot(v, self.w_i_UPD_vh, dims=1) + torch.tensordot(short_term_mem, self.w_i_UPD_sh, dims=1) + self.b_i_UPD)
		# modify long-term memory:
		long_term_mem = torch.add(torch.mul(i_LR, i_UPD), long_term_mem)
		# Output Gate
		o = sigmoid(torch.tensordot(v, self.w_o_xh, dims=1) + torch.tensordot(short_term_mem, self.w_o_sh, dims=1) + self.b_o)
		# modify short-term memory:
		short_term_mem = torch.mul(o, torch.tanh(long_term_mem))
		# Output
		output = self.softmax(torch.tensordot(short_term_mem, self.o_o, dims=1))
		return short_term_mem, long_term_mem, output


# Read txt file, convert to list of lists
def read_file(file_name):
	with open(file_name, 'r') as file:
		data = file.read().split('\n')
		data = [line.replace('.','').split() for line in data]
		# pad with <S> and <E>
		for line in data:
			line.insert(0, '<S>')
			line.append('<E>')
		# normalize
		data = [[word.lower() for word in line] for line in data]
		# get vocabulary
		vocab = set([word for line in data for word in line])
		# convert to sorted list to preserve word order
		vocab = sorted(list(vocab))
		# get word to index dictionary
		word_to_ix = {word: float(i) for i, word in enumerate(vocab)}
		# convert words to indices
		data = [[word_to_ix[word] for word in line] for line in data]
		# convert to tensor
	return data, len(vocab), word_to_ix

X_in, input_size, word_to_ix = read_file('data_LSTM_text.txt')

hidden_size = 5
embedding_size = 5

stm = torch.tensor([0.0]*hidden_size).to(device)
ltm = torch.tensor([0.0]*hidden_size).to(device)

lstm = LSTM(input_size, hidden_size, embedding_size).to(device)
optimizer = torch.optim.Adam(lstm.parameters(), lr=0.01)

# for i in tqdm(range(500)):
# 	for x in X_in:
# 		loss = 0
# 		for i in range(len(x)-1):
# 			# convert to tensor
# 			word_tensor = torch.zeros(input_size).to(device)
# 			target_tensor = torch.zeros(input_size).to(device)
# 			word_tensor[int(x[i])] = 1
# 			target_tensor[int(x[i+1])] = 1
# 			word = torch.tensor(word_tensor).to(device)
# 			target = torch.tensor(target_tensor).to(device)
# 			# forward pass
# 			stm, ltm, out = lstm(word, stm, ltm)
# 			# calculate loss
# 			loss += nn.CrossEntropyLoss()(out, target)
# 		# zero gradients
# 		optimizer.zero_grad()
# 		# backward pass
# 		loss.backward()
# 		# update weights
# 		optimizer.step()
# 		# zero out short-term memory
# 		stm = torch.tensor([0.0]*hidden_size).to(device)
# 		ltm = torch.tensor([0.0]*hidden_size).to(device)

# # save model
# torch.save(lstm.state_dict(), 'lstm_model_embed.pth')

# Load model
lstm = LSTM(input_size, hidden_size, embedding_size).to(device)
lstm.load_state_dict(torch.load('lstm_model_embed.pth'))

#invert vocab
ix_to_word = {v: k for k, v in word_to_ix.items()}

lstm.eval()

# Test
stm = torch.tensor([0.0]*hidden_size).to(device)
ltm = torch.tensor([0.0]*hidden_size).to(device)

# input = ['<s>', 'today', 'was', 'not', 'too']
# for word in input:
# 	# convert to tensor
# 	word_tensor = torch.zeros(input_size).to(device)
# 	word_tensor[int(word_to_ix[word])] = 1
# 	word = torch.tensor(word_tensor).to(device)
# 	# forward pass
# 	stm, ltm, out = lstm(word, stm, ltm)
# 	# print output
# 	word_out = ix_to_word[torch.argmax(out).item()]

# print(word_out)


# stm = torch.tensor([0.0]*hidden_size).to(device)
# ltm = torch.tensor([0.0]*hidden_size).to(device)

# input = ['<s>', 'yesterday', 'was', 'not', 'too']
# for word in input:
# 	# convert to tensor
# 	word_tensor = torch.zeros(input_size).to(device)
# 	word_tensor[int(word_to_ix[word])] = 1
# 	word = torch.tensor(word_tensor).to(device)
# 	# forward pass
# 	stm, ltm, out = lstm(word, stm, ltm)
# 	# print output
# 	word_out = ix_to_word[torch.argmax(out).item()]

# print(word_out)


input =['<s>']

while input[-1] != '<e>':
	# convert to tensor
	word_tensor = torch.zeros(input_size).to(device)
	word_tensor[int(word_to_ix[input[-1]])] = 1
	word = torch.tensor(word_tensor).to(device)
	# forward pass
	stm, ltm, out = lstm(word, stm, ltm)
	# print output
	word_out = ix_to_word[torch.multinomial(out, 1).item()]
	print(word_out)
	input.append(word_out)

