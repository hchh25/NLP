# PYTORCH VERSION:

import torch
import torch.nn as nn

if torch.backends.mps.is_available():
	device = torch.device("mps")
elif torch.cuda.is_available():
	device = torch.device("cuda")
else:
	device = torch.device("cpu")

def sigmoid(x):
	return 1 / (1 + torch.exp(-x))


class LSTM(nn.Module):
	def __init__(self):
		super(LSTM, self).__init__()
		self.w_f_xh = torch.tensor([1.63]).to(device)
		self.w_f_sh = torch.tensor([2.7]).to(device)
		self.b_f = torch.tensor([1.62]).to(device)

		self.w_i_LR_xh = torch.tensor([1.65]).to(device)
		self.w_i_LR_sh = torch.tensor([2.0]).to(device)
		self.b_i_LR = torch.tensor([0.62]).to(device)
		
		self.w_i_UPD_xh = torch.tensor([0.94]).to(device)
		self.w_i_UPD_sh = torch.tensor([1.41]).to(device)
		self.b_i_UPD = torch.tensor([-0.32]).to(device)
		
		self.w_o_xh = torch.tensor([-0.19]).to(device)
		self.w_o_sh = torch.tensor([4.38]).to(device)
		self.b_o = torch.tensor([0.59]).to(device)
	
	def forward(self, x, short_term_mem, long_term_mem):
		# Forget Gate
		f = sigmoid(torch.dot(x, self.w_f_xh) + torch.dot(short_term_mem, self.w_f_sh) + self.b_f)

		# modify long-term memory:
		long_term_mem = torch.mul(f, long_term_mem)
		
		# Input Gate
		i_LR = sigmoid(torch.dot(x, self.w_i_LR_xh) + torch.dot(short_term_mem, self.w_i_LR_sh) + self.b_i_LR)
		
		i_UPD = torch.tanh(torch.dot(x, self.w_i_UPD_xh) + torch.dot(short_term_mem, self.w_i_UPD_sh) + self.b_i_UPD)
		
		# modify long-term memory:
		long_term_mem = torch.add(torch.mul(i_LR, i_UPD), long_term_mem)
		
		# Output Gate
		o = sigmoid(torch.dot(x, self.w_o_xh) + torch.dot(short_term_mem, self.w_o_sh) + self.b_o)
		
		# modify short-term memory:
		short_term_mem = torch.mul(o, torch.tanh(long_term_mem))
		
		return short_term_mem, long_term_mem

x_1 = torch.tensor([[0.0], [0.5], [0.25], [1.0]]).to(device)
x_2 = torch.tensor([[1.0], [0.5], [0.25], [1.0]]).to(device)

s1 = torch.tensor([0.0]).to(device)
l1 = torch.tensor([0.0]).to(device)
s2 = torch.tensor([0.0]).to(device)
l2 = torch.tensor([0.0]).to(device)

lstm = LSTM().to(device)

for i in range(len(x_1)):
	s1, l1 = lstm(x_1[i], s1, l1)
	s2, l2 = lstm(x_2[i], s2, l2)
	print("s1: ", s1.item(), "l1: ", l1.item(), "s2: ", s2.item(), "l2: ", l2.item())

